import { Text, SafeAreaView, StyleSheet, View, TextInput, Button } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from '../components/AssetExample';

import { useNavigation } from '@react-navigation/native';

export default function Register() {
  const navigation = useNavigation();
  return (
    <View>
      
    </View>
  );
}

const styles = StyleSheet.create({
  
});
