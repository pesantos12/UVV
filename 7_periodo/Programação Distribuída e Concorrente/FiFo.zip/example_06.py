import queue

fila_fifo = queue.Queue()
fila_fifo.put("Primeiro da fila")
fila_fifo.put("Segundo da fila")
fila_fifo.put("Terceiro da fila")

print("FIFO: ", fila_fifo.get())

fila_lifo = queue.Queue()
fila_lifo.put((532,"Primeiro da fila"))
fila_lifo.put((89,"Segundo da fila"))
fila_lifo.put((53,"Terceiro da fila"))

print("PRIOR: ", fila_lifo.get())