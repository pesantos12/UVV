import threading

def function(i):
    print('Funcao chamada pelo thread %i\n' % i)
    return False 

threads = [] 

for i in range(5):
    t = threading.Thread(target = function, args=(i, ))
    threads.append(t)
    t.start()
    t.join()

print(threads)
