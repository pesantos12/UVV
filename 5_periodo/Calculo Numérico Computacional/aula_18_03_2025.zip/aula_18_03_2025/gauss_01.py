# gauss_01.py
def print_matrix(M, decimals=3):
    """
    Print a matrix one row at a time
    :param M: The matrix to be printed
    """
    for row in M:
        print([round(x, decimals)+0 for x in row])

def zeros_matrix(rows, cols):
    """
    Cria uma matriz de zeros
    :param rows: numero de linhas
    :param cols: numero de colunas
    :return: matriz quadrada de zeros
    """
    M = []
    while len(M) < rows:
        M.append([])
        while len(M[-1]) < cols:
            M[-1].append(0.0)
    return M

def coef_matrix(augMat):
    """
    Recupera a matriz Coeficientes para o calculo do Determinante
    :param M: Matriz aumentada
    :return: Matriz Coeficiente
    """
    # Recuperando as dimensoes da matriz coeficiente
    rows = len(augMat)
    cols = len(augMat[0])

    # Section 2: Create a new matrix of zeros
    MC = zeros_matrix(rows, cols - 1)

    # Section 3: Copy values of M into the copy
    for i in range(rows):
        for j in range(cols - 1):
            MC[i][j] = augMat[i][j]

    return MC

def determinant(AM):
    """
    Calcula o determinante a partir da matriz triangular superior
    O produto da diagonal principal eh o valor do determinante
    :param AM: matriz de coeficientes
    :return: determinante da matriz
    """
    n = len(AM)
    # Reducao a forma triangular superior
    for fd in range(n): # fd: foco diagonal values
        if AM[fd][fd] == 0:
            for j in range(fd + 1, n):
                if AM[j][fd] != 0:
                    AM[fd], AM[j] = AM[j], AM[fd]
                    break
            else:
                # If no non-zero pivot is found, the matrix might be singular
                # Se um pivo nao for encontrado, a matriz eh singular
                raise ValueError("Matriz singular!.")

        for i in range(fd+1, n): # skip row with fd in it.
            crScaler = AM[i][fd] / AM[fd][fd] # cr stands for "current row".
            for j in range(n): # cr - crScaler * fdRow, one element at a time.
                AM[i][j] = AM[i][j] - crScaler * AM[fd][j]

    # Uma vez que temos a forma triangular, calculamos o produto da diagonal principal
    product = 1.0
    for i in range(n):
        product *= AM[i][i]
    return product

def verifica_non_singularidade(A):
    """
    Verifica se a matriz eh NAO SINGULAR
    :param A: Matriz a ser avaliada
    :return: boolean True ou raise ArithmeticError
    """
    det = determinant(A)
    if det != 0:
        return True
    else:
        raise ArithmeticError("Matriz Singular!")

def GaussJordanMethod(augMat):
    n = len(augMat) # Numero de linhas
    m = len(augMat[0]) # Numero de colunas

    for i in range(n):
        # Check if the pivot element is zero and swap rows if necessary
        # Verifica se o pivo eh zero e muda a linha se necessario
        if augMat[i][i] == 0:
            for j in range(i + 1, n):
                if augMat[j][i] != 0:
                    augMat[i], augMat[j] = augMat[j], augMat[i]
                    break
                else:
                    # If no non-zero pivot is found, the matrix might be singular
                    # Se um pivo nao for encontrado, a matriz eh singular
                    raise ValueError("Matriz singular!.")

        # Normalizando cada linha
        # L_i <-- L_i/a_ii
        if augMat[i][i] != 1:
            divisor = augMat[i][i]
            for k in range(m):
                augMat[i][k] /= divisor
        else:
            pass
        
        # Zera as entradas referentes aos pivos
        # L_j <-- L_j - a_ji * L_i
        for j in range(n):
            if i != j:
                coef = augMat[j][i]
                for k in range(m):
                    augMat[j][k] -= coef * augMat[i][k]
            else:
                pass

    print(augMat)

def GaussJordan(matrix):
    mc = coef_matrix(matrix)
    print_matrix(mc)
    det = determinant(mc)
    print(det)
    result = verifica_non_singularidade(mc)
    print(result)



#matrix = [[3.0, 2.0, -4.0, 3.0], [2.0, 3.0, 3.0, 15.0], [5.0, -3, 1.0, 14.0]]
#matrix = [[0, 2, 0, 1, 0], [2, 2, 3, 2, -2], [4, -3, 0, 1, -7], [6, 1, -6, -5, 6]]

#matrix = [[2.0, 3.0, 5.0], [4.0, -1.0, 7.0]] 
# a) sem solução, dízima preriódica

matrix = [[2.0, 3.0, 1.0, 0.0], [1.0, -2.0, -1.0, 1.0], [1.0, 4.0, 1.0, 2.0]]
# b) 0.25, 1.75, 4.75

#matrix = [[2.0, 2.0, -3.0, 4.0], [1.0, 3.0, 1.0, 11.0], [2.0, 5.0, -4.0, 13.0]]




GaussJordanMethod(matrix)